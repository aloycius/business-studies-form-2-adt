// @vitest-environment jsdom
import { expect, it } from "vitest"
import { wrapWordsForElement, unwrapWordsForElement, setWordHighlight } from "./word-highlight"

it("preserves semantic tables and source-positioned text while wrapping", () => {
  const page = document.createElement("section")
  page.innerHTML = '<h2>Trade receivables</h2> <table><tbody><tr><th>Details</th><td><span style="position:absolute;left:120px;top:32px">Balance b/d</span></td></tr></tbody></table>'
  const original = page.innerHTML
  const text = page.textContent!
  const table = page.querySelector("table")
  const positioned = page.querySelector<HTMLElement>("td > span")!
  wrapWordsForElement(page, text)
  expect(page.querySelector("table")).toBe(table)
  expect(page.querySelector("td > span")).toBe(positioned)
  expect(positioned.style.left).toBe("120px")
  expect(page.textContent).toBe(text)
  setWordHighlight(page, 0)
  expect(page.querySelector("h2 .bg-yellow-300")?.textContent).toBe("Trade")
  unwrapWordsForElement(page)
  expect(page.innerHTML).toBe(original)
})

it("keeps positioned segment widths on their container during read-aloud", () => {
  const p = document.createElement("p")
  const segments = [
    { text: "Physical features: ", style: { display: "inline-block", width: "85px", "font-style": "italic", "white-space": "pre" } },
    { text: "White with erect ears", style: { display: "inline-block", width: "105px", "letter-spacing": "-0.1px" } },
  ]
  p.dataset.segments = JSON.stringify(segments)
  p.innerHTML = "<span>Original source layout</span>"
  const original = p.innerHTML
  wrapWordsForElement(p, "")
  expect(p.children).toHaveLength(2)
  expect((p.children[0] as HTMLElement).style.width).toBe("85px")
  expect(p.querySelectorAll('[data-word-index][style*="width"]')).toHaveLength(0)
  expect(p.textContent).toBe(segments.map(s => s.text).join(""))
  expect((p.querySelector('[data-word-index]') as HTMLElement).style.font).toBe("inherit")
  const wrapped = p.innerHTML
  wrapWordsForElement(p, "")
  expect(p.innerHTML).toBe(wrapped)
  unwrapWordsForElement(p)
  expect(p.innerHTML).toBe(original)
})

it("highlights all pieces of a word spanning positioned style runs", () => {
  const p = document.createElement("p")
  p.dataset.segments = JSON.stringify([
    { text: "Agri", style: { width: "20px" } },
    { text: "culture book", style: { width: "50px" } },
  ])
  wrapWordsForElement(p, "")
  setWordHighlight(p, 0)
  expect(p.querySelectorAll(".bg-yellow-300")).toHaveLength(2)
  setWordHighlight(p, 1)
  expect(p.querySelectorAll(".bg-yellow-300")).toHaveLength(1)
})

it("keeps source-line highlight wrappers inside their original font runs", () => {
  const p = document.createElement("p")
  p.dataset.sourceLine = "1"
  p.style.fontSize = "16px"
  p.dataset.segments = JSON.stringify([
    { text: "Plant's ", style: { "font-size": "12px", "font-family": "Tinos" } },
    { text: "food-making", style: { "font-size": "12px", "font-weight": "bold" } },
  ])
  p.innerHTML = "<span>Plant's </span><strong>food-making</strong>"
  const original = p.innerHTML
  wrapWordsForElement(p, "")
  expect(p.textContent).toBe("Plant's food-making")
  expect(p.children).toHaveLength(2)
  for (const child of p.children) expect((child as HTMLElement).style.fontSize).toBe("12px")
  expect(p.querySelectorAll(":scope > [data-word-index]")).toHaveLength(0)
  unwrapWordsForElement(p)
  expect(p.innerHTML).toBe(original)
})
