import { atom } from "jotai"
import { videoFilesAtom } from "@/features/language/state/language.atoms"
import {
  currentPageNumberAtom,
  currentSectionIdAtom,
  pagesAtom,
} from "@/features/navigation/state/nav.atoms"

/** Video filename assigned to the current runtime page, if one exists. */
export const currentPageSignLanguageVideoAtom = atom((get) => {
  const pageNumber = get(currentPageNumberAtom)
  const sectionId = get(currentSectionIdAtom)
  const pages = get(pagesAtom)
  const pageEntry = sectionId
    ? pages.find((page) => page.section_id === sectionId)
    : undefined

  // Covers are navigation surfaces, not numbered content pages. Their sign
  // videos are assigned separately instead of borrowing a numbered page video.
  if (pageEntry?.cover_type) return null

  const pageIndex =
    pageNumber ??
    pageEntry?.page_number ??
    (sectionId ? pages.findIndex((page) => page.section_id === sectionId) + 1 : 0)

  if (pageIndex < 1) return null
  return get(videoFilesAtom)[`video-${pageIndex}`] ?? null
})
