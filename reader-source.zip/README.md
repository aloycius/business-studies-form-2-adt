# ADT reader source

Corresponding source for the ADT browser reader distributed with this book, including the runtime changes present during this conversion. Textbook content retains its original rights.

Upstream: https://github.com/unicef/adt-studio
License: GNU AGPL v3 or later (see LICENSE).

With Node.js 20+ and pnpm 10.32.1:

```sh
pnpm install --no-frozen-lockfile
pnpm exec tsc -p packages/types
pnpm --filter @adt/runtime build
```

Output: `assets/adt/base.bundle.local.js` and companion bundles. The published book also contains its generated HTML and CSS in editable form. The included upstream lockfile records the dependency versions used for the original build; this narrowed workspace may rewrite unrelated importer records when installing.
